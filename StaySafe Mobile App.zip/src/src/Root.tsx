import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Toaster } from 'sonner@2.0.3';

// Импорт всех экранов
import OnboardingScreen from './screens/OnboardingScreen';
import HomeScreen from './screens/HomeScreen';
import MapScreen from './screens/MapScreen';
import AlertScreen from './screens/AlertScreen';
import ContactsScreen from './screens/ContactsScreen';
import FakeCallScreen from './screens/FakeCallScreen';
import FakeCalculatorScreen from './screens/FakeCalculatorScreen';
import AboutScreen from './screens/AboutScreen';

// Сервисы
import { storage } from './services/storage';

// Типы экранов
type ScreenType = 
  | 'onboarding'
  | 'home'
  | 'map'
  | 'alert'
  | 'contacts'
  | 'fake-call'
  | 'fake-calculator'
  | 'about';

const Root: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('onboarding');
  const [isLoading, setIsLoading] = useState(true);

  // Проверка онбординга при загрузке
  useEffect(() => {
    const checkOnboarding = () => {
      const hasSeenOnboarding = storage.getOnboardingSeen();
      
      if (hasSeenOnboarding) {
        // Проверяем deep link из URL
        const urlParams = new URLSearchParams(window.location.search);
        const linkScreen = urlParams.get('screen');
        
        if (linkScreen && ['map', 'alert', 'contacts', 'fake-call', 'fake-calculator', 'about'].includes(linkScreen)) {
          setCurrentScreen(linkScreen as ScreenType);
        } else {
          setCurrentScreen('home');
        }
      } else {
        setCurrentScreen('onboarding');
      }
      
      setIsLoading(false);
    };

    // Небольшая задержка для плавности
    setTimeout(checkOnboarding, 500);
  }, []);

  // Обработка deep links
  useEffect(() => {
    const handleDeepLink = () => {
      const hash = window.location.hash.replace('#', '');
      const path = window.location.pathname.replace('/', '');
      
      let targetScreen: ScreenType | null = null;
      
      // Обработка различных форматов deep links
      if (hash === 'map' || path === 'map') targetScreen = 'map';
      else if (hash === 'alert' || path === 'alert') targetScreen = 'alert';
      else if (hash === 'contacts' || path === 'contacts') targetScreen = 'contacts';
      else if (hash === 'fake-call' || path === 'fake-call') targetScreen = 'fake-call';
      else if (hash === 'fake-calculator' || path === 'fake-calculator') targetScreen = 'fake-calculator';
      else if (hash === 'about' || path === 'about') targetScreen = 'about';
      
      if (targetScreen && storage.getOnboardingSeen()) {
        setCurrentScreen(targetScreen);
      }
    };

    // Слушаем изменения URL
    window.addEventListener('hashchange', handleDeepLink);
    window.addEventListener('popstate', handleDeepLink);
    
    return () => {
      window.removeEventListener('hashchange', handleDeepLink);
      window.removeEventListener('popstate', handleDeepLink);
    };
  }, []);

  // Навигация между экранами
  const navigate = (screen: ScreenType) => {
    setCurrentScreen(screen);
    
    // Обновляем URL для deep links
    if (screen !== 'home' && screen !== 'onboarding') {
      window.history.pushState({}, '', `#${screen}`);
    } else {
      window.history.pushState({}, '', '/');
    }
  };

  const navigateBack = () => {
    setCurrentScreen('home');
    window.history.pushState({}, '', '/');
  };

  const handleOnboardingComplete = () => {
    setCurrentScreen('home');
  };

  // Загрузочный экран
  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gradient-to-br from-pink-50 to-purple-50">
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div 
            className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
            style={{ 
              background: 'linear-gradient(135deg, #E57399 0%, #F4C2C2 100%)'
            }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
              className="w-8 h-8 border-2 border-white border-t-transparent rounded-full"
            />
          </div>
          <h2 className="text-xl font-semibold text-gray-800">StaySafe</h2>
          <p className="text-sm text-gray-600 mt-1">Загрузка...</p>
        </motion.div>
      </div>
    );
  }

  // Рендер текущего экрана
  const renderCurrentScreen = () => {
    switch (currentScreen) {
      case 'onboarding':
        return <OnboardingScreen onComplete={handleOnboardingComplete} />;
      
      case 'home':
        return <HomeScreen onNavigate={navigate} />;
      
      case 'map':
        return <MapScreen onBack={navigateBack} />;
      
      case 'alert':
        return (
          <AlertScreen 
            onBack={navigateBack} 
            onNavigateToMap={() => navigate('map')} 
          />
        );
      
      case 'contacts':
        return <ContactsScreen onBack={navigateBack} />;
      
      case 'fake-call':
        return <FakeCallScreen onBack={navigateBack} />;
      
      case 'fake-calculator':
        return <FakeCalculatorScreen onBack={navigateBack} />;
      
      case 'about':
        return <AboutScreen onBack={navigateBack} />;
      
      default:
        return <HomeScreen onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen">
      {/* Основной контент с анимацией переходов */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentScreen}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ 
            duration: 0.3,
            ease: 'easeInOut'
          }}
          className="min-h-screen"
        >
          {renderCurrentScreen()}
        </motion.div>
      </AnimatePresence>

      {/* Система уведомлений */}
      <Toaster
        position="top-center"
        toastOptions={{
          duration: 3000,
          style: {
            background: 'white',
            color: '#222222',
            border: '1px solid rgba(0,0,0,0.1)',
            borderRadius: '12px',
            padding: '12px 16px',
            fontSize: '14px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
          },
          success: {
            style: {
              background: '#F0FDF4',
              color: '#15803D',
              border: '1px solid #BBF7D0',
            },
          },
          error: {
            style: {
              background: '#FEF2F2',
              color: '#DC2626',
              border: '1px solid #FECACA',
            },
          },
        }}
      />

      {/* PWA мета-теги для мобильных устройств */}
      <div style={{ display: 'none' }}>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="StaySafe" />
        <meta name="theme-color" content="#E57399" />
      </div>
    </div>
  );
};

export default Root;
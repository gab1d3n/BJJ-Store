import React from 'react';
import { motion } from 'motion/react';
import { 
  MapPin, 
  Shield, 
  Building2, 
  GraduationCap, 
  Cross,
  Users
} from 'lucide-react';
import { SafePlace } from '../constants/safePlaces.almaty';
import { colors } from '../constants/colors';

interface SafePlaceMarkerProps {
  place: SafePlace;
  isSelected?: boolean;
  onClick?: () => void;
  distance?: number;
}

const SafePlaceMarker: React.FC<SafePlaceMarkerProps> = ({ 
  place, 
  isSelected = false, 
  onClick,
  distance 
}) => {
  const getIcon = () => {
    switch (place.type) {
      case 'police':
        return <Shield className="w-4 h-4" />;
      case 'mall':
        return <Building2 className="w-4 h-4" />;
      case 'hospital':
        return <Cross className="w-4 h-4" />;
      case 'university':
        return <GraduationCap className="w-4 h-4" />;
      case 'public':
        return <Users className="w-4 h-4" />;
      default:
        return <MapPin className="w-4 h-4" />;
    }
  };

  const getColor = () => {
    switch (place.type) {
      case 'police':
        return '#1E40AF'; // Синий
      case 'mall':
        return '#7C3AED'; // Фиолетовый
      case 'hospital':
        return '#DC2626'; // Красный
      case 'university':
        return '#059669'; // Зеленый
      case 'public':
        return '#D97706'; // Оранжевый
      default:
        return colors.primary;
    }
  };

  const formatDistance = (dist: number): string => {
    if (dist < 1) {
      return `${Math.round(dist * 1000)} м`;
    }
    return `${dist.toFixed(1)} км`;
  };

  return (
    <motion.div
      className="cursor-pointer"
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{ type: 'spring', stiffness: 300 }}
    >
      <div className="relative">
        {/* Основной маркер */}
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center text-white shadow-lg border-2 border-white relative"
          style={{ 
            backgroundColor: isSelected ? colors.danger : getColor(),
            transform: isSelected ? 'scale(1.2)' : 'scale(1)',
            transition: 'all 0.2s ease'
          }}
        >
          {getIcon()}
          
          {/* Пульсирующая анимация для выбранного маркера */}
          {isSelected && (
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-red-400"
              animate={{ 
                scale: [1, 1.5, 2],
                opacity: [0.6, 0.3, 0]
              }}
              transition={{ 
                duration: 2, 
                repeat: Infinity,
                ease: 'easeOut'
              }}
            />
          )}
        </div>

        {/* Информационная подсказка */}
        {isSelected && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute top-12 left-1/2 transform -translate-x-1/2 z-10"
          >
            <div className="bg-white rounded-lg shadow-lg border p-3 min-w-48">
              <h4 className="font-semibold text-sm mb-1" style={{ color: colors.text }}>
                {place.name}
              </h4>
              
              <div className="flex items-center justify-between">
                <span 
                  className="text-xs px-2 py-1 rounded-full text-white"
                  style={{ backgroundColor: getColor() }}
                >
                  {place.type}
                </span>
                
                {distance !== undefined && (
                  <span className="text-xs text-gray-500">
                    {formatDistance(distance)}
                  </span>
                )}
              </div>
              
              {/* Стрелочка */}
              <div 
                className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-b-4 border-transparent border-b-white"
              />
            </div>
          </motion.div>
        )}

        {/* Бейдж с расстоянием */}
        {distance !== undefined && !isSelected && (
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="absolute -top-2 -right-2 bg-white text-xs px-1 py-0.5 rounded-full shadow border text-gray-600"
          >
            {formatDistance(distance)}
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

export default SafePlaceMarker;
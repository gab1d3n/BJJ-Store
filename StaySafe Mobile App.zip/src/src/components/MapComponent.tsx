import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { 
  MapPin, 
  Navigation, 
  Target, 
  Route,
  AlertCircle,
  MapIcon,
  Clock
} from 'lucide-react';
import SafePlaceMarker from './SafePlaceMarker';
import { Button } from '../../components/ui/button';
import { Card } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { toast } from 'sonner@2.0.3';
import { colors } from '../constants/colors';
import { safePlacesAlmaty, almatyCenter, SafePlace } from '../constants/safePlaces.almaty';
import { locationService, Coordinates } from '../services/location';
import { routingService } from '../services/routing';

// Простой компонент карты без внешних зависимостей
interface MapComponentProps {
  center: Coordinates;
  zoom: number;
  markers: Array<{
    id: string;
    position: Coordinates;
    title: string;
    type: 'safe-place' | 'current' | 'destination';
    data?: SafePlace;
  }>;
  selectedMarkerId?: string;
  onMarkerClick?: (id: string) => void;
  onMapClick?: (coords: Coordinates) => void;
  routeLine?: Coordinates[];
}

const MapComponent: React.FC<MapComponentProps> = ({
  center,
  zoom,
  markers,
  selectedMarkerId,
  onMarkerClick,
  onMapClick,
  routeLine
}) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [mapCenter, setMapCenter] = useState(center);

  // Простая карта-заглушка для веб-версии
  const handleMapClick = (event: React.MouseEvent<HTMLDivElement>) => {
    if (!onMapClick || isDragging) return;
    
    const rect = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    // Примерное преобразование координат экрана в географические
    const lat = center.latitude + (0.5 - y / rect.height) * 0.1;
    const lon = center.longitude + (x / rect.width - 0.5) * 0.1;
    
    onMapClick({ latitude: lat, longitude: lon });
  };

  const getMarkerIcon = (type: string) => {
    switch (type) {
      case 'current':
        return <Navigation className="w-4 h-4 text-blue-600" />;
      case 'destination':
        return <Target className="w-4 h-4 text-red-600" />;
      default:
        return <MapPin className="w-4 h-4 text-green-600" />;
    }
  };

  const getMarkerColor = (type: string, isSelected: boolean) => {
    if (isSelected) return colors.danger;
    
    switch (type) {
      case 'current':
        return '#2563EB';
      case 'destination':
        return colors.danger;
      default:
        return colors.success;
    }
  };

  return (
    <div className="relative w-full h-full">
      {/* Карта-заглушка */}
      <div
        ref={mapRef}
        className="w-full h-full bg-gradient-to-br from-blue-100 to-green-100 relative overflow-hidden cursor-crosshair"
        onClick={handleMapClick}
        style={{
          backgroundImage: `
            radial-gradient(circle at 20% 20%, rgba(34, 197, 94, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 80% 80%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 40% 60%, rgba(168, 85, 247, 0.05) 0%, transparent 50%)
          `
        }}
      >
        {/* Сетка карты */}
        <div className="absolute inset-0 opacity-10">
          {Array.from({ length: 20 }, (_, i) => (
            <div
              key={`vertical-grid-${i}`}
              className="absolute bg-gray-400"
              style={{
                left: `${i * 5}%`,
                top: 0,
                width: '1px',
                height: '100%'
              }}
            />
          ))}
          {Array.from({ length: 20 }, (_, i) => (
            <div
              key={`horizontal-grid-${i}`}
              className="absolute bg-gray-400"
              style={{
                top: `${i * 5}%`,
                left: 0,
                height: '1px',
                width: '100%'
              }}
            />
          ))}
        </div>

        {/* Линия маршрута */}
        {routeLine && routeLine.length > 1 && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            <path
              d={`M ${routeLine.map((point, index) => {
                const x = ((point.longitude - center.longitude) / 0.1 + 0.5) * 100;
                const y = (0.5 - (point.latitude - center.latitude) / 0.1) * 100;
                return `${index === 0 ? 'M' : 'L'} ${x}% ${y}%`;
              }).join(' ')}`}
              stroke={colors.primary}
              strokeWidth="3"
              strokeDasharray="8 4"
              fill="none"
              className="animate-pulse"
            />
          </svg>
        )}

        {/* Маркеры */}
        {markers.map((marker) => {
          const x = ((marker.position.longitude - center.longitude) / 0.1 + 0.5) * 100;
          const y = (0.5 - (marker.position.latitude - center.latitude) / 0.1) * 100;
          const isSelected = marker.id === selectedMarkerId;
          const markerColor = getMarkerColor(marker.type, isSelected);

          // Для безопасных мест используем специальный компонент
          if (marker.type === 'safe-place' && marker.data) {
            return (
              <div
                key={marker.id}
                className="absolute transform -translate-x-1/2 -translate-y-1/2"
                style={{
                  left: `${Math.max(0, Math.min(100, x))}%`,
                  top: `${Math.max(0, Math.min(100, y))}%`,
                  zIndex: isSelected ? 20 : 10
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  onMarkerClick?.(marker.id);
                }}
              >
                <SafePlaceMarker
                  place={marker.data}
                  isSelected={isSelected}
                />
              </div>
            );
          }

          // Для остальных маркеров используем базовый вид
          return (
            <motion.div
              key={marker.id}
              className="absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2"
              style={{
                left: `${Math.max(0, Math.min(100, x))}%`,
                top: `${Math.max(0, Math.min(100, y))}%`,
                zIndex: isSelected ? 20 : 10
              }}
              onClick={(e) => {
                e.stopPropagation();
                onMarkerClick?.(marker.id);
              }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center shadow-lg border-2 border-white"
                style={{ 
                  backgroundColor: markerColor,
                  transform: isSelected ? 'scale(1.2)' : 'scale(1)'
                }}
              >
                {getMarkerIcon(marker.type)}
              </div>
              
              {isSelected && marker.title && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute top-10 left-1/2 transform -translate-x-1/2 whitespace-nowrap"
                >
                  <div 
                    className="bg-white px-2 py-1 rounded shadow-lg text-xs font-medium border"
                    style={{ color: colors.text }}
                  >
                    {marker.title}
                  </div>
                </motion.div>
              )}
            </motion.div>
          );
        })}

        {/* Индикатор того, что это заглушка */}
        <div className="absolute top-4 left-4">
          <Badge variant="secondary" className="bg-white/90">
            <MapIcon className="w-3 h-3 mr-1" />
            Демо карта
          </Badge>
        </div>
      </div>
    </div>
  );
};

export default MapComponent;
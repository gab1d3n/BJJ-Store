import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  User, 
  Phone, 
  MessageCircle, 
  MessageSquare, 
  Send, 
  Edit3, 
  Trash2,
  MoreVertical
} from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Card } from '../../components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../../components/ui/dropdown-menu';
import { toast } from 'sonner@2.0.3';
import { colors } from '../constants/colors';
import { EmergencyContact } from '../services/storage';
import { linksService } from '../services/links';
import { locationService } from '../services/location';

interface ContactItemProps {
  contact: EmergencyContact;
  onEdit: (contact: EmergencyContact) => void;
  onDelete: (id: string) => void;
}

const ContactItem: React.FC<ContactItemProps> = ({ contact, onEdit, onDelete }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const sendHelpMessage = async (method: 'whatsapp' | 'sms' | 'telegram') => {
    try {
      const coords = await locationService.getCurrentCoords();
      const helpText = linksService.buildHelpText(coords);
      
      let url = '';
      let appName = '';
      
      switch (method) {
        case 'whatsapp':
          url = linksService.waLink(helpText, contact.phone);
          appName = 'WhatsApp';
          break;
        case 'sms':
          url = linksService.smsLink(helpText, contact.phone);
          appName = 'SMS';
          break;
        case 'telegram':
          url = linksService.tgLink(helpText);
          appName = 'Telegram';
          break;
      }
      
      const success = await linksService.openLink(url);
      
      if (success) {
        toast.success(`${appName} открыт для ${contact.name}`);
      } else {
        toast.error(`Не удалось открыть ${appName}`);
      }
    } catch (error) {
      const helpText = linksService.buildHelpText();
      
      let url = '';
      
      switch (method) {
        case 'whatsapp':
          url = linksService.waLink(helpText, contact.phone);
          break;
        case 'sms':
          url = linksService.smsLink(helpText, contact.phone);
          break;
        case 'telegram':
          url = linksService.tgLink(helpText);
          break;
      }
      
      await linksService.openLink(url);
      toast.success(`Сообщение отправлено ${contact.name} (без геолокации)`);
    }
  };

  const callContact = () => {
    const url = linksService.telLink(contact.phone);
    linksService.openLink(url);
    toast.success(`Звонок ${contact.name}`);
  };

  const formatPhone = (phone: string) => {
    // Простое форматирование номера телефона
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.startsWith('7') && cleaned.length === 11) {
      return `+7 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7, 9)}-${cleaned.slice(9)}`;
    } else if (cleaned.startsWith('8') && cleaned.length === 11) {
      return `+7 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7, 9)}-${cleaned.slice(9)}`;
    }
    return phone;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      layout
    >
      <Card className="overflow-hidden">
        <div className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 flex-1">
              <div 
                className="w-12 h-12 rounded-full flex items-center justify-center text-white"
                style={{ backgroundColor: colors.primary }}
              >
                <User className="w-6 h-6" />
              </div>
              
              <div className="flex-1">
                <h3 className="font-semibold" style={{ color: colors.text }}>
                  {contact.name}
                </h3>
                <p className="text-sm text-gray-500">
                  {formatPhone(contact.phone)}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsExpanded(!isExpanded)}
                style={{ color: colors.primary }}
              >
                {isExpanded ? 'Свернуть' : 'Действия'}
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="p-2">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onEdit(contact)}>
                    <Edit3 className="w-4 h-4 mr-2" />
                    Редактировать
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => onDelete(contact.id)}
                    className="text-red-600"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Удалить
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
          
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 pt-4 border-t space-y-3"
            >
              <p className="text-sm text-gray-600">
                Быстро отправить сообщение о помощи:
              </p>
              
              <div className="grid grid-cols-2 gap-2">
                <Button
                  onClick={callContact}
                  size="sm"
                  variant="outline"
                  className="flex items-center space-x-2"
                  style={{ borderColor: colors.success, color: colors.success }}
                >
                  <Phone className="w-4 h-4" />
                  <span>Позвонить</span>
                </Button>
                
                <Button
                  onClick={() => sendHelpMessage('sms')}
                  size="sm"
                  variant="outline"
                  className="flex items-center space-x-2"
                  style={{ borderColor: '#007AFF', color: '#007AFF' }}
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>SMS</span>
                </Button>
                
                <Button
                  onClick={() => sendHelpMessage('whatsapp')}
                  size="sm"
                  variant="outline"
                  className="flex items-center space-x-2"
                  style={{ borderColor: '#25D366', color: '#25D366' }}
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp</span>
                </Button>
                
                <Button
                  onClick={() => sendHelpMessage('telegram')}
                  size="sm"
                  variant="outline"
                  className="flex items-center space-x-2"
                  style={{ borderColor: '#0088CC', color: '#0088CC' }}
                >
                  <Send className="w-4 h-4" />
                  <span>Telegram</span>
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </Card>
    </motion.div>
  );
};

export default ContactItem;
export const colors = {
  bg: '#FFF5F7',
  primary: '#E57399',
  primaryMuted: '#F4C2C2',
  text: '#222222',
  card: '#FFFFFF',
  mapAccent: '#5FA8D3',
  danger: '#D72638',
  success: '#4CAF50',
  warning: '#FF9800',
  gradient: {
    primary: 'linear-gradient(135deg, #E57399 0%, #F4C2C2 100%)',
    danger: 'linear-gradient(135deg, #D72638 0%, #FF6B7A 100%)',
    success: 'linear-gradient(135deg, #4CAF50 0%, #8BC34A 100%)',
  }
};
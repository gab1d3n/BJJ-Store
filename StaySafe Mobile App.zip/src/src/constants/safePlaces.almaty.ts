export interface SafePlace {
  id: string;
  name: string;
  lat: number;
  lon: number;
  type: 'mall' | 'police' | 'hospital' | 'university' | 'public';
}

export const safePlacesAlmaty: SafePlace[] = [
  { 
    id: 'sp1', 
    name: 'Esentai Mall — Security Point', 
    lat: 43.2076, 
    lon: 76.9063,
    type: 'mall'
  },
  { 
    id: 'sp2', 
    name: 'MEGA Alma-Ata — Info Desk', 
    lat: 43.2089, 
    lon: 76.8703,
    type: 'mall'
  },
  { 
    id: 'sp3', 
    name: 'Al-Farabi KazNU — Guard Post', 
    lat: 43.2220, 
    lon: 76.9518,
    type: 'university'
  },
  { 
    id: 'sp4', 
    name: 'Panfilov Park — Police Booth', 
    lat: 43.2644, 
    lon: 76.9533,
    type: 'police'
  },
  { 
    id: 'sp5', 
    name: 'Abay Ave — Patrol Point', 
    lat: 43.2421, 
    lon: 76.9059,
    type: 'police'
  },
  {
    id: 'sp6',
    name: 'City Hospital #1 — Emergency',
    lat: 43.2385,
    lon: 76.8958,
    type: 'hospital'
  },
  {
    id: 'sp7',
    name: 'Dostyk Plaza — Security',
    lat: 43.2342,
    lon: 76.9059,
    type: 'mall'
  }
];

// Центр Алматы для центрирования карты
export const almatyCenter = {
  lat: 43.238949,
  lon: 76.889709
};
// Локальное хранилище для веб-версии приложения

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
}

const ONBOARDING_KEY = 'staysafe_onboarding_seen';
const CONTACTS_KEY = 'emergency_contacts_v1';

export const storage = {
  // Онбординг
  getOnboardingSeen: (): boolean => {
    try {
      return localStorage.getItem(ONBOARDING_KEY) === 'true';
    } catch {
      return false;
    }
  },

  setOnboardingSeen: (seen: boolean): void => {
    try {
      localStorage.setItem(ONBOARDING_KEY, seen.toString());
    } catch (error) {
      console.error('Failed to save onboarding status:', error);
    }
  },

  // Экстренные контакты
  getEmergencyContacts: (): EmergencyContact[] => {
    try {
      const contacts = localStorage.getItem(CONTACTS_KEY);
      return contacts ? JSON.parse(contacts) : [];
    } catch {
      return [];
    }
  },

  setEmergencyContacts: (contacts: EmergencyContact[]): void => {
    try {
      localStorage.setItem(CONTACTS_KEY, JSON.stringify(contacts));
    } catch (error) {
      console.error('Failed to save emergency contacts:', error);
    }
  },

  addEmergencyContact: (contact: Omit<EmergencyContact, 'id'>): EmergencyContact => {
    const newContact: EmergencyContact = {
      ...contact,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9)
    };
    
    const contacts = storage.getEmergencyContacts();
    contacts.push(newContact);
    storage.setEmergencyContacts(contacts);
    
    return newContact;
  },

  updateEmergencyContact: (id: string, updates: Partial<EmergencyContact>): boolean => {
    const contacts = storage.getEmergencyContacts();
    const index = contacts.findIndex(c => c.id === id);
    
    if (index === -1) return false;
    
    contacts[index] = { ...contacts[index], ...updates };
    storage.setEmergencyContacts(contacts);
    
    return true;
  },

  deleteEmergencyContact: (id: string): boolean => {
    const contacts = storage.getEmergencyContacts();
    const filteredContacts = contacts.filter(c => c.id !== id);
    
    if (filteredContacts.length === contacts.length) return false;
    
    storage.setEmergencyContacts(filteredContacts);
    return true;
  }
};
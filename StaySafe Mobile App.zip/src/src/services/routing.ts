// Сервис для расчета расстояний и поиска ближайших точек

import { Coordinates } from './location';
import { SafePlace } from '../constants/safePlaces.almaty';

export const routingService = {
  // Расчет расстояния по формуле Haversine (в километрах)
  haversineDistance: (point1: Coordinates, point2: Coordinates): number => {
    const R = 6371; // Радиус Земли в километрах
    const dLat = routingService.toRad(point2.latitude - point1.latitude);
    const dLon = routingService.toRad(point2.longitude - point1.longitude);
    
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(routingService.toRad(point1.latitude)) * 
      Math.cos(routingService.toRad(point2.latitude)) * 
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;
    
    return distance;
  },

  // Конвертация градусов в радианы
  toRad: (degrees: number): number => {
    return degrees * (Math.PI / 180);
  },

  // Поиск ближайшей безопасной точки
  findNearest: (
    currentLocation: Coordinates, 
    places: SafePlace[]
  ): { place: SafePlace; distance: number } | null => {
    if (places.length === 0) return null;

    let nearest = places[0];
    let minDistance = routingService.haversineDistance(
      currentLocation, 
      { latitude: nearest.lat, longitude: nearest.lon }
    );

    for (let i = 1; i < places.length; i++) {
      const place = places[i];
      const distance = routingService.haversineDistance(
        currentLocation,
        { latitude: place.lat, longitude: place.lon }
      );

      if (distance < minDistance) {
        nearest = place;
        minDistance = distance;
      }
    }

    return {
      place: nearest,
      distance: minDistance
    };
  },

  // Сортировка мест по расстоянию
  sortByDistance: (
    currentLocation: Coordinates,
    places: SafePlace[]
  ): Array<{ place: SafePlace; distance: number }> => {
    return places
      .map(place => ({
        place,
        distance: routingService.haversineDistance(
          currentLocation,
          { latitude: place.lat, longitude: place.lon }
        )
      }))
      .sort((a, b) => a.distance - b.distance);
  },

  // Форматирование расстояния для отображения
  formatDistance: (distance: number): string => {
    if (distance < 1) {
      return `${Math.round(distance * 1000)} м`;
    } else {
      return `${distance.toFixed(1)} км`;
    }
  },

  // Расчет времени в пути (примерная скорость ходьбы 5 км/ч)
  estimateWalkingTime: (distance: number): string => {
    const walkingSpeedKmh = 5;
    const timeInHours = distance / walkingSpeedKmh;
    const timeInMinutes = Math.round(timeInHours * 60);
    
    if (timeInMinutes < 60) {
      return `${timeInMinutes} мин`;
    } else {
      const hours = Math.floor(timeInMinutes / 60);
      const minutes = timeInMinutes % 60;
      return `${hours}ч ${minutes}мин`;
    }
  },

  // Создание координат для прямой линии между двумя точками
  createStraightLine: (
    from: Coordinates,
    to: Coordinates,
    points: number = 100
  ): Coordinates[] => {
    const line: Coordinates[] = [];
    
    for (let i = 0; i <= points; i++) {
      const ratio = i / points;
      const lat = from.latitude + (to.latitude - from.latitude) * ratio;
      const lon = from.longitude + (to.longitude - from.longitude) * ratio;
      
      line.push({ latitude: lat, longitude: lon });
    }
    
    return line;
  }
};
// Сервис геолокации для веб-версии

export interface Coordinates {
  latitude: number;
  longitude: number;
}

export interface LocationPermissionStatus {
  granted: boolean;
  error?: string;
}

export const locationService = {
  // Запрос разрешения на геолокацию
  requestLocationPermission: async (): Promise<LocationPermissionStatus> => {
    if (!navigator.geolocation) {
      return {
        granted: false,
        error: 'Геолокация не поддерживается вашим браузером'
      };
    }

    try {
      // Проверяем текущее состояние разрешений
      const permission = await navigator.permissions.query({ name: 'geolocation' });
      
      if (permission.state === 'granted') {
        return { granted: true };
      }
      
      if (permission.state === 'denied') {
        return {
          granted: false,
          error: 'Доступ к геолокации запрещен. Разрешите доступ в настройках браузера.'
        };
      }

      // Состояние 'prompt' - нужно запросить разрешение
      return { granted: true }; // Разрешение будет запрошено при первом вызове getCurrentCoords
    } catch {
      return { granted: true }; // Fallback для старых браузеров
    }
  },

  // Получение текущих координат
  getCurrentCoords: (): Promise<Coordinates> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Геолокация не поддерживается'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          let errorMessage = 'Не удалось получить местоположение';
          
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = 'Доступ к геолокации запрещен';
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = 'Местоположение недоступно';
              break;
            case error.TIMEOUT:
              errorMessage = 'Время ожидания истекло';
              break;
          }
          
          reject(new Error(errorMessage));
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 60000
        }
      );
    });
  },

  // Отслеживание местоположения
  watchPosition: (
    onSuccess: (coords: Coordinates) => void,
    onError?: (error: string) => void
  ): number | null => {
    if (!navigator.geolocation) {
      onError?.('Геолокация не поддерживается');
      return null;
    }

    return navigator.geolocation.watchPosition(
      (position) => {
        onSuccess({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
      },
      (error) => {
        let errorMessage = 'Ошибка отслеживания местоположения';
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'Доступ к геолокации запрещен';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Местоположение недоступно';
            break;
          case error.TIMEOUT:
            errorMessage = 'Время ожидания истекло';
            break;
        }
        
        onError?.(errorMessage);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000
      }
    );
  },

  // Остановка отслеживания
  clearWatch: (watchId: number): void => {
    navigator.geolocation.clearWatch(watchId);
  }
};
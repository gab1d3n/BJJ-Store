// Сервис для создания deep links и внешних ссылок

import { Coordinates } from './location';

export const linksService = {
  // Создание текста помощи с геолокацией
  buildHelpText: (coords?: Coordinates): string => {
    const baseText = 'Мне срочно нужна помощь!';
    
    if (coords) {
      const mapsUrl = linksService.gmapsLink(coords.latitude, coords.longitude);
      return `${baseText} Моё местоположение: ${coords.latitude.toFixed(6)}, ${coords.longitude.toFixed(6)}. Карта: ${mapsUrl}`;
    }
    
    return baseText;
  },

  // WhatsApp ссылка
  waLink: (text: string, phone?: string): string => {
    const encodedText = encodeURIComponent(text);
    
    if (phone) {
      // Убираем все символы кроме цифр и плюса
      const cleanPhone = phone.replace(/[^\d+]/g, '');
      return `https://wa.me/${cleanPhone}?text=${encodedText}`;
    }
    
    return `https://wa.me/?text=${encodedText}`;
  },

  // SMS ссылка
  smsLink: (text: string, phone?: string): string => {
    const encodedText = encodeURIComponent(text);
    
    if (phone) {
      const cleanPhone = phone.replace(/[^\d+]/g, '');
      return `sms:${cleanPhone}?body=${encodedText}`;
    }
    
    return `sms:?body=${encodedText}`;
  },

  // Telegram ссылка
  tgLink: (text: string): string => {
    const encodedText = encodeURIComponent(text);
    return `https://t.me/share/url?url=&text=${encodedText}`;
  },

  // Google Maps ссылка
  gmapsLink: (lat: number, lon: number): string => {
    return `https://maps.google.com/?q=${lat},${lon}`;
  },

  // Телефонная ссылка
  telLink: (phone: string): string => {
    const cleanPhone = phone.replace(/[^\d+]/g, '');
    return `tel:${cleanPhone}`;
  },

  // Email ссылка
  mailtoLink: (email: string, subject?: string, body?: string): string => {
    let link = `mailto:${email}`;
    const params = new URLSearchParams();
    
    if (subject) params.append('subject', subject);
    if (body) params.append('body', body);
    
    const queryString = params.toString();
    if (queryString) {
      link += `?${queryString}`;
    }
    
    return link;
  },

  // Открытие ссылки с обработкой ошибок
  openLink: async (url: string): Promise<boolean> => {
    try {
      window.open(url, '_blank');
      return true;
    } catch (error) {
      console.error('Failed to open link:', error);
      return false;
    }
  },

  // Копирование в буфер обмена
  copyToClipboard: async (text: string): Promise<boolean> => {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Fallback для старых браузеров
      try {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        return true;
      } catch {
        return false;
      }
    }
  }
};
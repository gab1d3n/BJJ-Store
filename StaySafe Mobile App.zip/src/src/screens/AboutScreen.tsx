import React from 'react';
import { motion } from 'motion/react';
import { 
  ArrowLeft, 
  Heart, 
  Mail, 
  Phone, 
  ExternalLink,
  Shield,
  Users,
  MapPin,
  AlertTriangle,
  Github,
  Globe
} from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Card } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Separator } from '../../components/ui/separator';
import { toast } from 'sonner@2.0.3';
import { colors } from '../constants/colors';
import { linksService } from '../services/links';

interface AboutScreenProps {
  onBack: () => void;
}

const AboutScreen: React.FC<AboutScreenProps> = ({ onBack }) => {
  const contactInfo = {
    phone: '+7 (700) 000-00-00',
    email: 'support@staysafe.kz',
    website: 'https://staysafe.kz'
  };

  const handleContactClick = async (type: 'phone' | 'email' | 'website') => {
    let url = '';
    let message = '';

    switch (type) {
      case 'phone':
        url = linksService.telLink(contactInfo.phone);
        message = 'Открываем телефон...';
        break;
      case 'email':
        url = linksService.mailtoLink(
          contactInfo.email,
          'Обращение в StaySafe',
          'Здравствуйте! У меня есть вопрос по приложению StaySafe:'
        );
        message = 'Открываем почтовое приложение...';
        break;
      case 'website':
        url = contactInfo.website;
        message = 'Открываем веб-сайт...';
        break;
    }

    const success = await linksService.openLink(url);
    if (success) {
      toast.success(message);
    } else {
      // Копируем контактную информацию в буфер обмена как fallback
      const textToCopy = type === 'phone' ? contactInfo.phone :
                        type === 'email' ? contactInfo.email :
                        contactInfo.website;
      
      const copied = await linksService.copyToClipboard(textToCopy);
      if (copied) {
        toast.success(`Контакт скопирован: ${textToCopy}`);
      } else {
        toast.error('Не удалось открыть ссылку');
      }
    }
  };

  const features = [
    {
      icon: <AlertTriangle className="w-5 h-5" />,
      title: 'Быстрая тревога',
      description: 'Мгновенная отправка сигналов о помощи'
    },
    {
      icon: <MapPin className="w-5 h-5" />,
      title: 'Карта безопасности',
      description: 'Поиск и навигация к безопасным местам'
    },
    {
      icon: <Users className="w-5 h-5" />,
      title: 'Экстренные контакты',
      description: 'Управление доверенными контактами'
    },
    {
      icon: <Shield className="w-5 h-5" />,
      title: 'Скрытые функции',
      description: 'Фейковый звонок и калькулятор с SOS'
    }
  ];

  const emergencyNumbers = [
    { service: 'Полиция', number: '102' },
    { service: 'Скорая помощь', number: '103' },
    { service: 'Пожарная служба', number: '101' },
    { service: 'Аварийная газовая', number: '104' }
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: colors.bg }}>
      {/* Шапка */}
      <div className="flex items-center justify-between p-4 bg-white shadow-sm">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-semibold text-lg" style={{ color: colors.text }}>
              О приложении
            </h1>
            <p className="text-sm text-gray-500">StaySafe v1.0.0</p>
          </div>
        </div>
        
        <Badge 
          variant="secondary" 
          className="bg-green-100 text-green-700 border-green-200"
        >
          <Heart className="w-3 h-3 mr-1" />
          Веб-версия
        </Badge>
      </div>

      <div className="p-6 max-w-2xl mx-auto space-y-6">
        {/* Логотип и описание */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div 
            className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4"
            style={{ background: colors.gradient.primary }}
          >
            <Heart className="w-10 h-10 text-white" />
          </div>
          
          <h2 className="text-2xl font-bold mb-2" style={{ color: colors.text }}>
            StaySafe
          </h2>
          
          <p className="text-gray-600 max-w-md mx-auto leading-relaxed">
            Приложение для повышения личной безопасности, разработанное с заботой 
            о женщинах и всех, кто ценит свою безопасность.
          </p>
        </motion.div>

        {/* Основные возможности */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="font-semibold mb-4" style={{ color: colors.text }}>
            Основные возможности
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <Card className="p-4 h-full">
                  <div className="flex items-start space-x-3">
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center text-white flex-shrink-0"
                      style={{ backgroundColor: colors.primary }}
                    >
                      {feature.icon}
                    </div>
                    <div>
                      <h4 className="font-medium text-sm mb-1" style={{ color: colors.text }}>
                        {feature.title}
                      </h4>
                      <p className="text-xs text-gray-500 leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Контактная информация */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <h3 className="font-semibold mb-4" style={{ color: colors.text }}>
            Связаться с нами
          </h3>
          
          <Card className="p-4">
            <p className="text-gray-600 mb-4 text-sm">
              Мы всегда рады вам помочь. Ваше обращение для нас важно.
            </p>
            
            <div className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start h-auto p-3"
                onClick={() => handleContactClick('phone')}
              >
                <Phone className="w-4 h-4 mr-3 flex-shrink-0" />
                <div className="text-left">
                  <div className="font-medium">Телефон</div>
                  <div className="text-sm text-gray-500">{contactInfo.phone}</div>
                </div>
                <ExternalLink className="w-4 h-4 ml-auto" />
              </Button>
              
              <Button
                variant="outline"
                className="w-full justify-start h-auto p-3"
                onClick={() => handleContactClick('email')}
              >
                <Mail className="w-4 h-4 mr-3 flex-shrink-0" />
                <div className="text-left">
                  <div className="font-medium">Электронная почта</div>
                  <div className="text-sm text-gray-500">{contactInfo.email}</div>
                </div>
                <ExternalLink className="w-4 h-4 ml-auto" />
              </Button>
              
              <Button
                variant="outline"
                className="w-full justify-start h-auto p-3"
                onClick={() => handleContactClick('website')}
              >
                <Globe className="w-4 h-4 mr-3 flex-shrink-0" />
                <div className="text-left">
                  <div className="font-medium">Веб-сайт</div>
                  <div className="text-sm text-gray-500">{contactInfo.website}</div>
                </div>
                <ExternalLink className="w-4 h-4 ml-auto" />
              </Button>
            </div>
          </Card>
        </motion.div>

        {/* Экстренные номера */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <h3 className="font-semibold mb-4" style={{ color: colors.text }}>
            Экстренные службы Казахстана
          </h3>
          
          <Card className="p-4">
            <div className="grid grid-cols-2 gap-3">
              {emergencyNumbers.map((emergency, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="h-auto p-3 flex flex-col items-center justify-center space-y-1"
                  onClick={() => {
                    const url = linksService.telLink(emergency.number);
                    linksService.openLink(url);
                    toast.success(`Вызов: ${emergency.service}`);
                  }}
                  style={{ borderColor: colors.danger, color: colors.danger }}
                >
                  <Phone className="w-4 h-4" />
                  <div className="text-center">
                    <div className="font-medium text-xs">{emergency.service}</div>
                    <div className="text-lg font-bold">{emergency.number}</div>
                  </div>
                </Button>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* Важная информация */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
        >
          <Card className="p-4 bg-amber-50 border-amber-200">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-amber-800 mb-2">
                  Важная информация
                </h4>
                <div className="text-sm text-amber-700 space-y-2">
                  <p>
                    • StaySafe является вспомогательным инструментом безопасности
                  </p>
                  <p>
                    • В реальных экстренных ситуациях всегда обращайтесь к службам экстренного реагирования
                  </p>
                  <p>
                    • Приложение не предназначено для хранения личных данных или конфиденциальной информации
                  </p>
                  <p>
                    • Используйте функции приложения ответственно и в соответствии с местным законодательством
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Версия и технологии */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="text-center"
        >
          <Separator className="mb-4" />
          
          <div className="space-y-2">
            <p className="text-sm text-gray-500">
              StaySafe Web Application v1.0.0
            </p>
            <p className="text-xs text-gray-400">
              Создано с ❤️ для вашей безопасности
            </p>
            <div className="flex items-center justify-center space-x-4 mt-3">
              <Badge variant="outline" className="text-xs">
                React
              </Badge>
              <Badge variant="outline" className="text-xs">
                TypeScript
              </Badge>
              <Badge variant="outline" className="text-xs">
                Tailwind CSS
              </Badge>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AboutScreen;
import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle, Shield, MapPin, Phone, Heart } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Card } from '../../components/ui/card';
import { Checkbox } from '../../components/ui/checkbox';
import { storage } from '../services/storage';
import { colors } from '../constants/colors';

interface OnboardingScreenProps {
  onComplete: () => void;
}

const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete }) => {
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const handleContinue = () => {
    storage.setOnboardingSeen(true);
    onComplete();
  };

  const features = [
    {
      icon: <Shield className="w-8 h-8" />,
      title: 'Быстрая тревога',
      description: 'Мгновенно отправляйте сообщения о помощи вашим близким'
    },
    {
      icon: <MapPin className="w-8 h-8" />,
      title: 'Карта безопасных мест',
      description: 'Находите ближайшие безопасные места и строите маршруты'
    },
    {
      icon: <Phone className="w-8 h-8" />,
      title: 'Экстренные контакты',
      description: 'Управляйте списком доверенных контактов для экстренных случаев'
    }
  ];

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center p-6"
      style={{ 
        background: colors.gradient.primary,
        color: colors.text 
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="w-full max-w-md space-y-8"
      >
        {/* Логотип и заголовок */}
        <div className="text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3, type: 'spring', stiffness: 200 }}
            className="w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center"
            style={{ backgroundColor: colors.card }}
          >
            <Heart className="w-10 h-10" style={{ color: colors.primary }} />
          </motion.div>
          
          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-3xl font-bold text-white mb-2"
          >
            StaySafe
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="text-white/90"
          >
            Ваша безопасность — наш приоритет
          </motion.p>
        </div>

        {/* Возможности */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="space-y-4"
        >
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1 + index * 0.2 }}
            >
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="flex items-start space-x-3">
                  <div className="text-white flex-shrink-0">
                    {feature.icon}
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-1">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-white/80">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Согласие с условиями */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.6 }}
          className="space-y-4"
        >
          <div className="flex items-start space-x-3">
            <Checkbox
              id="terms"
              checked={agreedToTerms}
              onCheckedChange={(checked) => setAgreedToTerms(checked as boolean)}
              className="mt-1"
            />
            <label htmlFor="terms" className="text-sm text-white/90 leading-relaxed">
              Я согласен(а) с использованием приложения StaySafe для обеспечения 
              личной безопасности и понимаю, что приложение предназначено для 
              вспомогательных функций безопасности.
            </label>
          </div>

          <Button
            onClick={handleContinue}
            disabled={!agreedToTerms}
            className="w-full bg-white text-gray-900 hover:bg-white/90 disabled:opacity-50"
            size="lg"
          >
            <CheckCircle className="w-5 h-5 mr-2" />
            Продолжить
          </Button>
        </motion.div>

        {/* Дополнительная информация */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.8 }}
          className="text-center"
        >
          <p className="text-xs text-white/70">
            StaySafe — это инструмент для повышения личной безопасности.
            <br />
            В экстренных ситуациях всегда обращайтесь к службам экстренного реагирования.
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default OnboardingScreen;
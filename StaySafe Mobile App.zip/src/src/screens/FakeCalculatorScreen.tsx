import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, AlertTriangle } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { toast } from 'sonner@2.0.3';
import { colors } from '../constants/colors';
import { linksService } from '../services/links';

interface FakeCalculatorScreenProps {
  onBack: () => void;
}

const FakeCalculatorScreen: React.FC<FakeCalculatorScreenProps> = ({ onBack }) => {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForNewValue, setWaitingForNewValue] = useState(false);

  const calculate = (firstValue: number, secondValue: number, operation: string): number => {
    switch (operation) {
      case '+':
        return firstValue + secondValue;
      case '-':
        return firstValue - secondValue;
      case '×':
        return firstValue * secondValue;
      case '÷':
        return firstValue / secondValue;
      case '=':
        return secondValue;
      default:
        return secondValue;
    }
  };

  const inputNumber = (num: string) => {
    if (waitingForNewValue) {
      setDisplay(num);
      setWaitingForNewValue(false);
    } else {
      // Prevent multiple decimal points
      if (num === '.' && display.includes('.')) {
        return;
      }
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const inputOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(inputValue);
    } else if (operation) {
      const currentValue = previousValue || 0;
      const newValue = calculate(currentValue, inputValue, operation);

      setDisplay(String(newValue));
      setPreviousValue(newValue);
    }

    setWaitingForNewValue(true);
    setOperation(nextOperation);
  };

  // Keyboard support
  React.useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // Prevent default for calculator-specific keys
      if (
        (e.key >= '0' && e.key <= '9') ||
        ['+', '-', '*', '/', '.', '=', 'Enter', 'Escape', 'Backspace'].includes(e.key)
      ) {
        e.preventDefault();
      }
      
      if (e.key >= '0' && e.key <= '9') {
        inputNumber(e.key);
      } else if (e.key === '.') {
        inputNumber('.');
      } else if (e.key === '+') {
        inputOperation('+');
      } else if (e.key === '-') {
        inputOperation('-');
      } else if (e.key === '*') {
        inputOperation('×');
      } else if (e.key === '/') {
        inputOperation('÷');
      } else if (e.key === 'Enter' || e.key === '=') {
        performCalculation();
      } else if (e.key === 'Escape') {
        clearAll();
      } else if (e.key === 'Backspace') {
        clearEntry();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [display, previousValue, operation, waitingForNewValue]);

  const performCalculation = () => {
    if (previousValue !== null && operation) {
      const inputValue = parseFloat(display);
      const newValue = calculate(previousValue, inputValue, operation);
      setDisplay(String(newValue));
      setPreviousValue(null);
      setOperation(null);
      setWaitingForNewValue(true);
    }
  };

  const clearAll = () => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForNewValue(false);
  };

  const clearEntry = () => {
    setDisplay('0');
    setWaitingForNewValue(false);
  };

  const toggleSign = () => {
    const value = parseFloat(display);
    setDisplay(String(value * -1));
  };

  const inputPercent = () => {
    const value = parseFloat(display);
    setDisplay(String(value / 100));
  };

  const handleSOS = () => {
    // Вибрация для привлечения внимания
    if (navigator.vibrate) {
      navigator.vibrate([200, 100, 200]);
    }

    // Звонок в полицию (102 для Казахстана)
    const policeNumber = '102';
    const url = linksService.telLink(policeNumber);
    linksService.openLink(url);
    
    toast.success('Вызов службы экстренного реагирования', {
      duration: 3000,
    });
  };

  // Скрытая кнопка возврата (долгое нажатие на заголовок)
  const [pressTimer, setPressTimer] = useState<NodeJS.Timeout | null>(null);

  const handleTitlePressStart = () => {
    const timer = setTimeout(() => {
      onBack();
      toast.success('Выход из скрытого режима');
    }, 2000); // 2 секунды долгого нажатия
    setPressTimer(timer);
  };

  const handleTitlePressEnd = () => {
    if (pressTimer) {
      clearTimeout(pressTimer);
      setPressTimer(null);
    }
  };

  const buttonStyle = "h-16 text-xl font-medium rounded-lg transition-colors duration-200";
  const numberButtonStyle = `${buttonStyle} bg-gray-100 hover:bg-gray-200 text-gray-900`;
  const operationButtonStyle = `${buttonStyle} text-white`;
  const functionButtonStyle = `${buttonStyle} bg-gray-300 hover:bg-gray-400 text-gray-900`;

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      {/* Заголовок с кнопками */}
      <motion.div
        className="bg-white shadow-sm p-4 select-none relative"
        onMouseDown={handleTitlePressStart}
        onMouseUp={handleTitlePressEnd}
        onMouseLeave={handleTitlePressEnd}
        onTouchStart={handleTitlePressStart}
        onTouchEnd={handleTitlePressEnd}
      >
        {/* Кнопка выхода */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="absolute top-3 left-3 text-gray-600 hover:text-gray-800 hover:bg-gray-100 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        
        <h1 className="text-center font-light text-lg text-gray-900">
          Калькулятор
        </h1>
        
        {/* Дополнительная скрытая кнопка для экстренного выхода */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="absolute top-3 right-3 opacity-10 hover:opacity-50 transition-opacity text-xs"
        >
          ✕
        </Button>
      </motion.div>

      {/* Дисплей */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-6 text-right shadow-sm"
      >
        <div className="text-4xl font-light text-gray-900 min-h-[3rem] flex items-end justify-end overflow-hidden">
          {display.length > 10 ? parseFloat(display).toExponential(5) : display}
        </div>
        {operation && (
          <div className="text-lg text-gray-500 mt-1">
            {previousValue} {operation}
          </div>
        )}
      </motion.div>

      {/* Кнопки */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex-1 p-4 grid grid-cols-4 gap-3"
      >
        {/* Первый ряд */}
        <Button onClick={clearAll} className={functionButtonStyle}>
          AC
        </Button>
        <Button onClick={clearEntry} className={functionButtonStyle}>
          C
        </Button>
        <Button onClick={toggleSign} className={functionButtonStyle}>
          ±
        </Button>
        <Button 
          onClick={() => inputOperation('÷')} 
          className={operationButtonStyle}
          style={{ backgroundColor: colors.primary }}
        >
          ÷
        </Button>

        {/* Второй ряд */}
        <Button onClick={() => inputNumber('7')} className={numberButtonStyle}>
          7
        </Button>
        <Button onClick={() => inputNumber('8')} className={numberButtonStyle}>
          8
        </Button>
        <Button onClick={() => inputNumber('9')} className={numberButtonStyle}>
          9
        </Button>
        <Button 
          onClick={() => inputOperation('×')} 
          className={operationButtonStyle}
          style={{ backgroundColor: colors.primary }}
        >
          ×
        </Button>

        {/* Третий ряд */}
        <Button onClick={() => inputNumber('4')} className={numberButtonStyle}>
          4
        </Button>
        <Button onClick={() => inputNumber('5')} className={numberButtonStyle}>
          5
        </Button>
        <Button onClick={() => inputNumber('6')} className={numberButtonStyle}>
          6
        </Button>
        <Button 
          onClick={() => inputOperation('-')} 
          className={operationButtonStyle}
          style={{ backgroundColor: colors.primary }}
        >
          −
        </Button>

        {/* Четвертый ряд */}
        <Button onClick={() => inputNumber('1')} className={numberButtonStyle}>
          1
        </Button>
        <Button onClick={() => inputNumber('2')} className={numberButtonStyle}>
          2
        </Button>
        <Button onClick={() => inputNumber('3')} className={numberButtonStyle}>
          3
        </Button>
        <Button 
          onClick={() => inputOperation('+')} 
          className={operationButtonStyle}
          style={{ backgroundColor: colors.primary }}
        >
          +
        </Button>

        {/* Пятый ряд */}
        <Button onClick={() => inputNumber('0')} className={numberButtonStyle}>
          0
        </Button>
        
        {/* SOS кнопка вместо 0 */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Button 
            onClick={handleSOS}
            className={`${buttonStyle} bg-red-500 hover:bg-red-600 text-white relative overflow-hidden`}
            style={{ 
              background: colors.gradient.danger,
              border: 'none'
            }}
          >
            <span className="relative z-10 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 mr-1" />
              SOS
            </span>
            <motion.div
              className="absolute inset-0 bg-white/20"
              animate={{ opacity: [0, 0.3, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </Button>
        </motion.div>
        
        <Button onClick={() => inputNumber('.')} className={numberButtonStyle}>
          ,
        </Button>
        <Button 
          onClick={performCalculation} 
          className={operationButtonStyle}
          style={{ backgroundColor: colors.primary }}
        >
          =
        </Button>
      </motion.div>

      {/* Подсказки */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="p-4 text-center space-y-2"
      >
        <p className="text-xs text-gray-400">
          ← Кнопка выхода • Долгое нажатие на заголовок • Клавиша Escape
        </p>
        <p className="text-xs text-red-400 font-medium">
          SOS кнопка вызывает службу экстренного реагирования (102)
        </p>
        <p className="text-xs text-gray-300">
          Поддерживается управление с клавиатуры
        </p>
      </motion.div>
    </div>
  );
};

export default FakeCalculatorScreen;
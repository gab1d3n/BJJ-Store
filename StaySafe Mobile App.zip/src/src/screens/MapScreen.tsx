import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowLeft,
  Navigation,
  MapPin,
  Route,
  Target,
  Clock,
  AlertCircle,
  Crosshair,
  Home
} from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Card } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { toast } from 'sonner@2.0.3';
import MapComponent from '../components/MapComponent';
import { colors } from '../constants/colors';
import { safePlacesAlmaty, almatyCenter, SafePlace } from '../constants/safePlaces.almaty';
import { locationService, Coordinates } from '../services/location';
import { routingService } from '../services/routing';
import { linksService } from '../services/links';

interface MapScreenProps {
  onBack: () => void;
}

const MapScreen: React.FC<MapScreenProps> = ({ onBack }) => {
  const [currentLocation, setCurrentLocation] = useState<Coordinates | null>(null);
  const [destination, setDestination] = useState<Coordinates | null>(null);
  const [selectedPlace, setSelectedPlace] = useState<SafePlace | null>(null);
  const [nearestPlace, setNearestPlace] = useState<{ place: SafePlace; distance: number } | null>(null);
  const [routeLine, setRouteLine] = useState<Coordinates[] | null>(null);
  const [mapCenter, setMapCenter] = useState<Coordinates>({
    latitude: almatyCenter.lat,
    longitude: almatyCenter.lon
  });
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);

  // Запрос геолокации при загрузке
  useEffect(() => {
    requestLocation();
  }, []);

  const requestLocation = async () => {
    setIsLoadingLocation(true);
    
    try {
      const permission = await locationService.requestLocationPermission();
      
      if (!permission.granted) {
        toast.error(permission.error || 'Доступ к геолокации не предоставлен');
        return;
      }

      const coords = await locationService.getCurrentCoords();
      setCurrentLocation(coords);
      setMapCenter(coords);
      
      toast.success('Местоположение определено');
    } catch (error) {
      toast.error((error as Error).message);
    } finally {
      setIsLoadingLocation(false);
    }
  };

  const findNearestSafePlace = () => {
    if (!currentLocation) {
      toast.error('Сначала определите ваше местоположение');
      return;
    }

    const nearest = routingService.findNearest(currentLocation, safePlacesAlmaty);
    
    if (nearest) {
      setNearestPlace(nearest);
      setSelectedPlace(nearest.place);
      setDestination({
        latitude: nearest.place.lat,
        longitude: nearest.place.lon
      });
      
      toast.success(`Ближайшее место: ${nearest.place.name} (${routingService.formatDistance(nearest.distance)})`);
    }
  };

  const handleMapClick = (coords: Coordinates) => {
    setDestination(coords);
    setSelectedPlace(null);
    setNearestPlace(null);
    
    if (currentLocation) {
      const distance = routingService.haversineDistance(currentLocation, coords);
      toast.success(`Выбрана цель (${routingService.formatDistance(distance)})`);
    } else {
      toast.success('Выбрана цель на карте');
    }
  };

  const handleMarkerClick = (markerId: string) => {
    const place = safePlacesAlmaty.find(p => p.id === markerId);
    
    if (place) {
      setSelectedPlace(place);
      setDestination({
        latitude: place.lat,
        longitude: place.lon
      });
      
      if (currentLocation) {
        const distance = routingService.haversineDistance(
          currentLocation,
          { latitude: place.lat, longitude: place.lon }
        );
        
        toast.success(`${place.name} (${routingService.formatDistance(distance)})`);
      }
    }
  };

  const buildRoute = () => {
    if (!currentLocation || !destination) {
      toast.error('Необходимо определить местоположение и выбрать цель');
      return;
    }

    // Создаем прямую линию как заглушку
    const line = routingService.createStraightLine(currentLocation, destination, 50);
    setRouteLine(line);
    
    const distance = routingService.haversineDistance(currentLocation, destination);
    const walkingTime = routingService.estimateWalkingTime(distance);
    
    toast.success(`Маршрут построен: ${routingService.formatDistance(distance)}, ~${walkingTime} пешком`);
  };

  const centerOnAlmaty = () => {
    setMapCenter({
      latitude: almatyCenter.lat,
      longitude: almatyCenter.lon
    });
    toast.success('Карта центрирована на Алматы');
  };

  const openInGoogleMaps = () => {
    if (!destination) {
      toast.error('Сначала выберите место назначения');
      return;
    }

    const url = linksService.gmapsLink(destination.latitude, destination.longitude);
    linksService.openLink(url);
  };

  // Подготовка маркеров для карты
  const markers = [];

  // Текущее местоположение
  if (currentLocation) {
    markers.push({
      id: 'current',
      position: currentLocation,
      title: 'Ваше местоположение',
      type: 'current' as const
    });
  }

  // Безопасные места
  safePlacesAlmaty.forEach(place => {
    markers.push({
      id: place.id,
      position: { latitude: place.lat, longitude: place.lon },
      title: place.name,
      type: 'safe-place' as const,
      data: place
    });
  });

  // Место назначения
  if (destination && !selectedPlace) {
    markers.push({
      id: 'destination',
      position: destination,
      title: 'Место назначения',
      type: 'destination' as const
    });
  }

  return (
    <div className="h-screen flex flex-col" style={{ backgroundColor: colors.bg }}>
      {/* Шапка */}
      <div className="flex items-center justify-between p-4 bg-white shadow-sm">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-semibold text-lg" style={{ color: colors.text }}>
              Карта безопасных мест
            </h1>
            <p className="text-sm text-gray-500">Алматы</p>
          </div>
        </div>
        
        <Button
          variant="outline"
          size="sm"
          onClick={centerOnAlmaty}
          className="flex items-center space-x-1"
        >
          <Home className="w-4 h-4" />
          <span className="hidden sm:inline">Алматы</span>
        </Button>
      </div>

      {/* Карта */}
      <div className="flex-1 relative">
        <MapComponent
          center={mapCenter}
          zoom={12}
          markers={markers}
          selectedMarkerId={selectedPlace?.id}
          onMarkerClick={handleMarkerClick}
          onMapClick={handleMapClick}
          routeLine={routeLine || undefined}
        />

        {/* Панель управления */}
        <div className="absolute top-4 right-4 space-y-2">
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Button
              onClick={requestLocation}
              disabled={isLoadingLocation}
              className="w-12 h-12 rounded-full shadow-lg"
              style={{ 
                backgroundColor: colors.primary,
                color: 'white'
              }}
            >
              {isLoadingLocation ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Crosshair className="w-5 h-5" />
              )}
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Button
              onClick={findNearestSafePlace}
              disabled={!currentLocation}
              className="w-12 h-12 rounded-full shadow-lg"
              style={{ 
                backgroundColor: colors.success,
                color: 'white'
              }}
            >
              <Target className="w-5 h-5" />
            </Button>
          </motion.div>

          {destination && (
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Button
                onClick={buildRoute}
                disabled={!currentLocation}
                className="w-12 h-12 rounded-full shadow-lg"
                style={{ 
                  backgroundColor: colors.mapAccent,
                  color: 'white'
                }}
              >
                <Route className="w-5 h-5" />
              </Button>
            </motion.div>
          )}
        </div>

        {/* Информационная панель */}
        {(selectedPlace || nearestPlace || destination) && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute bottom-4 left-4 right-4"
          >
            <Card className="p-4 bg-white/95 backdrop-blur-sm">
              {selectedPlace && (
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold" style={{ color: colors.text }}>
                        {selectedPlace.name}
                      </h3>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge variant="secondary" className="text-xs">
                          {selectedPlace.type}
                        </Badge>
                        {currentLocation && (
                          <span className="text-sm text-gray-500">
                            {routingService.formatDistance(
                              routingService.haversineDistance(
                                currentLocation,
                                { latitude: selectedPlace.lat, longitude: selectedPlace.lon }
                              )
                            )}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <Button
                      onClick={openInGoogleMaps}
                      size="sm"
                      variant="outline"
                    >
                      <Navigation className="w-4 h-4 mr-1" />
                      Google Maps
                    </Button>
                  </div>
                  
                  {currentLocation && routeLine && (
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <Route className="w-4 h-4" />
                        <span>
                          {routingService.formatDistance(
                            routingService.haversineDistance(
                              currentLocation,
                              { latitude: selectedPlace.lat, longitude: selectedPlace.lon }
                            )
                          )}
                        </span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>
                          ~{routingService.estimateWalkingTime(
                            routingService.haversineDistance(
                              currentLocation,
                              { latitude: selectedPlace.lat, longitude: selectedPlace.lon }
                            )
                          )}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </Card>
          </motion.div>
        )}

        {/* Инструкции для пользователя */}
        {!currentLocation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
          >
            <Card className="p-4 text-center bg-white/95 backdrop-blur-sm">
              <AlertCircle className="w-8 h-8 mx-auto mb-2" style={{ color: colors.warning }} />
              <p className="text-sm" style={{ color: colors.text }}>
                Нажмите кнопку <Crosshair className="w-4 h-4 inline mx-1" /> для определения местоположения
              </p>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default MapScreen;
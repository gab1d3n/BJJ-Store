import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowLeft,
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  User
} from 'lucide-react';
import { Button } from '../../components/ui/button';
import { colors } from '../constants/colors';

interface FakeCallScreenProps {
  onBack: () => void;
}

const FakeCallScreen: React.FC<FakeCallScreenProps> = ({ onBack }) => {
  const [callDuration, setCallDuration] = useState(0);
  const [isCallActive, setIsCallActive] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (isCallActive) {
      interval = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isCallActive]);

  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEndCall = () => {
    setIsCallActive(false);
    setTimeout(() => {
      onBack();
    }, 1000);
  };

  const callerInfo = {
    name: 'Папа',
    number: '+7 (777) 123-45-67',
    avatar: null // В реальном приложении здесь была бы фотография
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-b from-gray-900 to-black text-white relative overflow-hidden">
      {/* Фоновая анимация */}
      <motion.div
        className="absolute inset-0 opacity-10"
        animate={{
          background: [
            'radial-gradient(circle at 30% 50%, rgba(59, 130, 246, 0.3) 0%, transparent 50%)',
            'radial-gradient(circle at 70% 50%, rgba(59, 130, 246, 0.3) 0%, transparent 50%)',
            'radial-gradient(circle at 30% 50%, rgba(59, 130, 246, 0.3) 0%, transparent 50%)'
          ]
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />

      {/* Скрытая кнопка возврата */}
      <div className="absolute top-4 left-4 z-10">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="text-white/50 hover:text-white opacity-30 hover:opacity-100 transition-opacity"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
      </div>

      {/* Статус звонка */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center pt-16 pb-8"
      >
        <p className="text-white/70 text-sm mb-2">
          {isCallActive ? 'Входящий вызов' : 'Вызов завершен'}
        </p>
        <motion.div
          animate={{ opacity: isCallActive ? [1, 0.7, 1] : 1 }}
          transition={{ duration: 2, repeat: isCallActive ? Infinity : 0 }}
          className="text-lg font-medium"
        >
          {formatDuration(callDuration)}
        </motion.div>
      </motion.div>

      {/* Информация о звонящем */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="flex-1 flex flex-col items-center justify-center space-y-6"
      >
        {/* Аватар */}
        <motion.div
          animate={{
            scale: isCallActive ? [1, 1.05, 1] : 1,
            rotate: isCallActive ? [0, 1, -1, 0] : 0
          }}
          transition={{
            duration: 3,
            repeat: isCallActive ? Infinity : 0,
            ease: 'easeInOut'
          }}
          className="relative"
        >
          <div 
            className="w-40 h-40 rounded-full flex items-center justify-center text-white border-4 border-white/20"
            style={{ backgroundColor: colors.primary }}
          >
            <User className="w-20 h-20" />
          </div>
          
          {isCallActive && (
            <motion.div
              className="absolute inset-0 rounded-full border-4 border-white/30"
              animate={{ scale: [1, 1.2, 1.4], opacity: [0.6, 0.3, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          )}
        </motion.div>

        {/* Имя и номер */}
        <div className="text-center">
          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-3xl font-light mb-2"
          >
            {callerInfo.name}
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="text-white/70"
          >
            {callerInfo.number}
          </motion.p>
        </div>

        {/* Дополнительная информация */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-center"
        >
          <p className="text-white/50 text-sm">
            {isCallActive ? 'Звонит...' : 'Вызов завершен'}
          </p>
        </motion.div>
      </motion.div>

      {/* Кнопки управления */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="pb-16 px-8"
      >
        {isCallActive ? (
          <div className="flex justify-center space-x-8 mb-8">
            {/* Мут */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsMuted(!isMuted)}
              className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center"
            >
              {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </motion.button>

            {/* Динамик */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsSpeakerOn(!isSpeakerOn)}
              className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center"
            >
              {isSpeakerOn ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
            </motion.button>
          </div>
        ) : (
          <div className="h-24" /> // Пустое пространство когда звонок завершен
        )}

        {/* Основные кнопки */}
        <div className="flex justify-center space-x-12">
          {isCallActive && (
            <>
              {/* Принять звонок */}
              <motion.button
                whileTap={{ scale: 0.9 }}
                className="w-20 h-20 rounded-full bg-green-500 flex items-center justify-center shadow-lg"
                animate={{
                  boxShadow: [
                    '0 0 0 0 rgba(34, 197, 94, 0.7)',
                    '0 0 0 20px rgba(34, 197, 94, 0)',
                    '0 0 0 0 rgba(34, 197, 94, 0)'
                  ]
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Phone className="w-8 h-8 text-white" />
              </motion.button>
            </>
          )}

          {/* Завершить звонок */}
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleEndCall}
            className="w-20 h-20 rounded-full bg-red-500 flex items-center justify-center shadow-lg"
            animate={isCallActive ? {
              boxShadow: [
                '0 0 0 0 rgba(239, 68, 68, 0.7)',
                '0 0 0 20px rgba(239, 68, 68, 0)',
                '0 0 0 0 rgba(239, 68, 68, 0)'
              ]
            } : {}}
            transition={{ duration: 2, repeat: isCallActive ? Infinity : 0 }}
          >
            <PhoneOff className="w-8 h-8 text-white" />
          </motion.button>
        </div>

        {/* Инструкция */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="text-center mt-8"
        >
          <p className="text-white/50 text-xs">
            Нажмите красную кнопку, чтобы {isCallActive ? 'завершить' : 'выйти'}
          </p>
        </motion.div>
      </motion.div>

      {/* Эффект завершения звонка */}
      {!isCallActive && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute inset-0 bg-black/50 flex items-center justify-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="text-center"
          >
            <PhoneOff className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <p className="text-xl">Вызов завершен</p>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};

export default FakeCallScreen;
import React from 'react';
import { motion } from 'motion/react';
import { 
  MapPin, 
  AlertTriangle, 
  Phone, 
  PhoneCall, 
  Calculator, 
  Info,
  Heart,
  Shield
} from 'lucide-react';
import { Card } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { colors } from '../constants/colors';

interface HomeScreenProps {
  onNavigate: (screen: string) => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ onNavigate }) => {
  const menuItems = [
    {
      id: 'map',
      title: 'Карта безопасных мест',
      description: 'Найти ближайшие безопасные места',
      icon: <MapPin className="w-8 h-8" />,
      color: colors.mapAccent,
      gradient: 'linear-gradient(135deg, #5FA8D3 0%, #74B9D8 100%)'
    },
    {
      id: 'alert',
      title: 'Быстрая тревога',
      description: 'Экстренный вызов помощи',
      icon: <AlertTriangle className="w-8 h-8" />,
      color: colors.danger,
      gradient: colors.gradient.danger
    },
    {
      id: 'contacts',
      title: 'Экстренные контакты',
      description: 'Управление доверенными контактами',
      icon: <Phone className="w-8 h-8" />,
      color: colors.primary,
      gradient: colors.gradient.primary
    },
    {
      id: 'fake-call',
      title: 'Фейковый звонок',
      description: 'Имитация входящего звонка',
      icon: <PhoneCall className="w-8 h-8" />,
      color: colors.success,
      gradient: colors.gradient.success
    },
    {
      id: 'fake-calculator',
      title: 'Скрытый калькулятор',
      description: 'Калькулятор с кнопкой SOS',
      icon: <Calculator className="w-8 h-8" />,
      color: '#6366F1',
      gradient: 'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)'
    },
    {
      id: 'about',
      title: 'О приложении',
      description: 'Информация и контакты',
      icon: <Info className="w-8 h-8" />,
      color: '#64748B',
      gradient: 'linear-gradient(135deg, #64748B 0%, #94A3B8 100%)'
    }
  ];

  const handleItemClick = (itemId: string) => {
    onNavigate(itemId);
  };

  return (
    <div 
      className="min-h-screen p-6"
      style={{ backgroundColor: colors.bg }}
    >
      <div className="max-w-2xl mx-auto">
        {/* Заголовок */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center mb-4">
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.3, type: 'spring', stiffness: 200 }}
              className="w-16 h-16 rounded-full flex items-center justify-center mr-3"
              style={{ 
                background: colors.gradient.primary,
                color: 'white'
              }}
            >
              <Heart className="w-8 h-8" />
            </motion.div>
            <div>
              <h1 className="text-3xl font-bold" style={{ color: colors.text }}>
                StaySafe
              </h1>
              <p className="text-sm" style={{ color: colors.text + '80' }}>
                Ваша безопасность превыше всего
              </p>
            </div>
          </div>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="flex items-center justify-center space-x-2 text-sm"
            style={{ color: colors.text + '60' }}
          >
            <Shield className="w-4 h-4" />
            <span>Всегда готов помочь</span>
          </motion.div>
        </motion.div>

        {/* Сетка меню */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          {menuItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9 + index * 0.1 }}
              whileHover={{ 
                scale: 1.02,
                transition: { duration: 0.2 }
              }}
              whileTap={{ scale: 0.98 }}
            >
              <Card 
                className="p-6 cursor-pointer transition-all duration-300 hover:shadow-lg border-0"
                style={{ 
                  background: colors.card,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.08)'
                }}
                onClick={() => handleItemClick(item.id)}
              >
                <div className="flex items-start space-x-4">
                  <motion.div
                    whileHover={{ rotate: 5 }}
                    className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ 
                      background: item.gradient,
                      color: 'white'
                    }}
                  >
                    {item.icon}
                  </motion.div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 
                      className="font-semibold mb-1 text-base"
                      style={{ color: colors.text }}
                    >
                      {item.title}
                    </h3>
                    <p 
                      className="text-sm leading-relaxed"
                      style={{ color: colors.text + '70' }}
                    >
                      {item.description}
                    </p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Нижняя информация */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="mt-8 text-center"
        >
          <Card 
            className="p-4 border-0"
            style={{ 
              background: 'linear-gradient(135deg, #FFF5F7 0%, #FFE5E9 100%)',
              color: colors.text
            }}
          >
            <div className="flex items-center justify-center space-x-2 mb-2">
              <AlertTriangle className="w-4 h-4" style={{ color: colors.danger }} />
              <span className="font-medium text-sm">Экстренные службы</span>
            </div>
            <p className="text-xs opacity-80">
              Полиция: 102 • Скорая помощь: 103 • Пожарная: 101
            </p>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default HomeScreen;
import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowLeft,
  AlertTriangle,
  MessageCircle,
  MessageSquare,
  Send,
  MapPin,
  Copy,
  Volume2,
  Flashlight,
  Phone
} from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Card } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { toast } from 'sonner@2.0.3';
import { colors } from '../constants/colors';
import { locationService, Coordinates } from '../services/location';
import { linksService } from '../services/links';

interface AlertScreenProps {
  onBack: () => void;
  onNavigateToMap: () => void;
}

const AlertScreen: React.FC<AlertScreenProps> = ({ onBack, onNavigateToMap }) => {
  const [currentLocation, setCurrentLocation] = useState<Coordinates | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [alertText, setAlertText] = useState('');
  const [isFlashlightOn, setIsFlashlightOn] = useState(false);

  useEffect(() => {
    getCurrentLocation();
  }, []);

  const getCurrentLocation = async () => {
    setIsLoadingLocation(true);
    
    try {
      const coords = await locationService.getCurrentCoords();
      setCurrentLocation(coords);
      
      const helpText = linksService.buildHelpText(coords);
      setAlertText(helpText);
    } catch (error) {
      console.error('Location error:', error);
      const helpText = linksService.buildHelpText();
      setAlertText(helpText);
    } finally {
      setIsLoadingLocation(false);
    }
  };

  const handleMainAlert = () => {
    // Вибрация (если поддерживается)
    if (navigator.vibrate) {
      navigator.vibrate([200, 100, 200, 100, 200]);
    }

    toast.success('Тревога активирована! Выберите способ отправки сообщения');
  };

  const sendWhatsApp = async () => {
    const url = linksService.waLink(alertText);
    const success = await linksService.openLink(url);
    
    if (success) {
      toast.success('WhatsApp открыт');
    } else {
      toast.error('Не удалось открыть WhatsApp. Попробуйте установить приложение.');
    }
  };

  const sendSMS = async () => {
    const url = linksService.smsLink(alertText);
    const success = await linksService.openLink(url);
    
    if (success) {
      toast.success('SMS приложение открыто');
    } else {
      toast.error('Не удалось открыть SMS приложение');
    }
  };

  const sendTelegram = async () => {
    const url = linksService.tgLink(alertText);
    const success = await linksService.openLink(url);
    
    if (success) {
      toast.success('Telegram открыт');
    } else {
      toast.error('Не удалось открыть Telegram. Попробуйте установить приложение.');
    }
  };

  const copyToClipboard = async () => {
    const success = await linksService.copyToClipboard(alertText);
    
    if (success) {
      toast.success('Текст скопирован в буфер обмена');
    } else {
      toast.error('Не удалось скопировать текст');
    }
  };

  const callPolice = () => {
    const url = linksService.telLink('102');
    linksService.openLink(url);
  };

  const toggleFlashlight = () => {
    // Веб-версия: эмуляция мигания экрана
    setIsFlashlightOn(!isFlashlightOn);
    
    if (!isFlashlightOn) {
      toast.success('Сигнальный режим включен');
      // Мигание экрана
      let count = 0;
      const flashInterval = setInterval(() => {
        document.body.style.backgroundColor = count % 2 === 0 ? 'white' : 'black';
        count++;
        
        if (count >= 10) {
          clearInterval(flashInterval);
          document.body.style.backgroundColor = '';
          setIsFlashlightOn(false);
          toast.success('Сигнальный режим выключен');
        }
      }, 200);
    }
  };

  const playAlarmSound = () => {
    // Веб-версия: эмуляция громкого звука через Audio API
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 1000; // 1000 Hz
      gainNode.gain.value = 0.3;
      
      oscillator.start();
      
      setTimeout(() => {
        oscillator.stop();
        toast.success('Звуковой сигнал воспроизведен');
      }, 2000);
      
    } catch (error) {
      toast.error('Не удалось воспроизвести звуковой сигнал');
    }
  };

  const messengers = [
    {
      name: 'WhatsApp',
      icon: <MessageCircle className="w-6 h-6" />,
      color: '#25D366',
      action: sendWhatsApp
    },
    {
      name: 'SMS',
      icon: <MessageSquare className="w-6 h-6" />,
      color: '#007AFF',
      action: sendSMS
    },
    {
      name: 'Telegram',
      icon: <Send className="w-6 h-6" />,
      color: '#0088CC',
      action: sendTelegram
    }
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: colors.bg }}>
      {/* Шапка */}
      <div className="flex items-center justify-between p-4 bg-white shadow-sm">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-semibold text-lg" style={{ color: colors.text }}>
              Быстрая тревога
            </h1>
            <p className="text-sm text-gray-500">Экстренный вызов помощи</p>
          </div>
        </div>
        
        <Badge 
          variant="destructive" 
          className="bg-red-100 text-red-700 border-red-200"
        >
          <AlertTriangle className="w-3 h-3 mr-1" />
          SOS
        </Badge>
      </div>

      <div className="p-6 max-w-2xl mx-auto space-y-6">
        {/* Главная кнопка тревоги */}
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: 'spring', stiffness: 200 }}
          className="text-center"
        >
          <motion.button
            onClick={handleMainAlert}
            className="w-48 h-48 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-2xl relative overflow-hidden"
            style={{ 
              background: colors.gradient.danger,
              border: `6px solid ${colors.danger}`
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            animate={{
              boxShadow: [
                '0 0 0 0 rgba(215, 38, 56, 0.7)',
                '0 0 0 20px rgba(215, 38, 56, 0)',
                '0 0 0 0 rgba(215, 38, 56, 0)'
              ]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeOut'
            }}
          >
            <div className="text-center">
              <AlertTriangle className="w-16 h-16 mx-auto mb-2" />
              <div>БЫСТРАЯ</div>
              <div>ТРЕВОГА</div>
            </div>
          </motion.button>
          
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-4 text-sm text-gray-600 max-w-xs mx-auto"
          >
            Нажмите для активации экстренного режима и отправки сообщений о помощи
          </motion.p>
        </motion.div>

        {/* Статус геолокации */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5" style={{ color: colors.primary }} />
                <div>
                  <p className="font-medium" style={{ color: colors.text }}>
                    Местоположение
                  </p>
                  <p className="text-sm text-gray-500">
                    {isLoadingLocation 
                      ? 'Определяется...' 
                      : currentLocation 
                        ? `${currentLocation.latitude.toFixed(6)}, ${currentLocation.longitude.toFixed(6)}`
                        : 'Недоступно'
                    }
                  </p>
                </div>
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={getCurrentLocation}
                disabled={isLoadingLocation}
              >
                {isLoadingLocation ? (
                  <div className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" />
                ) : (
                  'Обновить'
                )}
              </Button>
            </div>
          </Card>
        </motion.div>

        {/* Текст сообщения */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="p-4">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="font-medium mb-2" style={{ color: colors.text }}>
                  Текст экстренного сообщения:
                </p>
                <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded border">
                  {alertText}
                </p>
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={copyToClipboard}
                className="ml-3"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </Card>
        </motion.div>

        {/* Способы отправки */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <h3 className="font-semibold mb-3" style={{ color: colors.text }}>
            Отправить сообщение о помощи:
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {messengers.map((messenger, index) => (
              <motion.div
                key={messenger.name}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + index * 0.1 }}
              >
                <Button
                  onClick={messenger.action}
                  className="w-full h-16 flex flex-col items-center justify-center space-y-1 text-white"
                  style={{ backgroundColor: messenger.color }}
                >
                  {messenger.icon}
                  <span className="text-sm">{messenger.name}</span>
                </Button>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Дополнительные действия */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <h3 className="font-semibold mb-3" style={{ color: colors.text }}>
            Дополнительные действия:
          </h3>
          
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={callPolice}
              variant="outline"
              className="h-16 flex flex-col items-center justify-center space-y-1"
              style={{ borderColor: colors.danger, color: colors.danger }}
            >
              <Phone className="w-6 h-6" />
              <span className="text-sm">Полиция 102</span>
            </Button>
            
            <Button
              onClick={onNavigateToMap}
              variant="outline"
              className="h-16 flex flex-col items-center justify-center space-y-1"
              style={{ borderColor: colors.mapAccent, color: colors.mapAccent }}
            >
              <MapPin className="w-6 h-6" />
              <span className="text-sm">Открыть карту</span>
            </Button>
            
            <Button
              onClick={playAlarmSound}
              variant="outline"
              className="h-16 flex flex-col items-center justify-center space-y-1"
              style={{ borderColor: colors.warning, color: colors.warning }}
            >
              <Volume2 className="w-6 h-6" />
              <span className="text-sm">Звуковой сигнал</span>
            </Button>
            
            <Button
              onClick={toggleFlashlight}
              variant="outline"
              className="h-16 flex flex-col items-center justify-center space-y-1"
              style={{ borderColor: colors.text, color: colors.text }}
            >
              <Flashlight className="w-6 h-6" />
              <span className="text-sm">Световой сигнал</span>
            </Button>
          </div>
        </motion.div>

        {/* Предупреждение */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          <Card className="p-4 bg-red-50 border-red-200">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-red-800 font-medium mb-1">
                  Важно помнить:
                </p>
                <p className="text-xs text-red-700 leading-relaxed">
                  Данное приложение является вспомогательным инструментом. 
                  В реальных экстренных ситуациях всегда обращайтесь к службам 
                  экстренного реагирования: Полиция 102, Скорая помощь 103, Пожарная 101.
                </p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default AlertScreen;
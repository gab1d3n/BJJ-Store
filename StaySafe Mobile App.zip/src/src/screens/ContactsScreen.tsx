import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Plus, 
  Users, 
  Phone, 
  User,
  AlertCircle,
  Search
} from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Card } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../../components/ui/dialog';
import { toast } from 'sonner@2.0.3';
import ContactItem from '../components/ContactItem';
import { colors } from '../constants/colors';
import { storage, EmergencyContact } from '../services/storage';

interface ContactsScreenProps {
  onBack: () => void;
}

const ContactsScreen: React.FC<ContactsScreenProps> = ({ onBack }) => {
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<EmergencyContact | null>(null);
  const [formData, setFormData] = useState({ name: '', phone: '' });
  const [formErrors, setFormErrors] = useState({ name: '', phone: '' });

  useEffect(() => {
    loadContacts();
  }, []);

  const loadContacts = () => {
    const savedContacts = storage.getEmergencyContacts();
    setContacts(savedContacts);
  };

  const validateForm = () => {
    const errors = { name: '', phone: '' };
    let isValid = true;

    if (!formData.name.trim()) {
      errors.name = 'Имя обязательно';
      isValid = false;
    } else if (formData.name.trim().length < 2) {
      errors.name = 'Имя должно содержать минимум 2 символа';
      isValid = false;
    }

    if (!formData.phone.trim()) {
      errors.phone = 'Номер телефона обязателен';
      isValid = false;
    } else {
      const phoneRegex = /^[\+]?[0-9\(\)\-\s]{7,}$/;
      if (!phoneRegex.test(formData.phone.trim())) {
        errors.phone = 'Некорректный номер телефона';
        isValid = false;
      }
    }

    setFormErrors(errors);
    return isValid;
  };

  const handleSaveContact = () => {
    if (!validateForm()) return;

    try {
      if (editingContact) {
        // Обновление существующего контакта
        const success = storage.updateEmergencyContact(editingContact.id, {
          name: formData.name.trim(),
          phone: formData.phone.trim()
        });
        
        if (success) {
          toast.success('Контакт обновлен');
        } else {
          toast.error('Ошибка при обновлении контакта');
        }
      } else {
        // Добавление нового контакта
        storage.addEmergencyContact({
          name: formData.name.trim(),
          phone: formData.phone.trim()
        });
        
        toast.success('Контакт добавлен');
      }
      
      loadContacts();
      handleCloseDialog();
    } catch (error) {
      toast.error('Ошибка при сохранении контакта');
    }
  };

  const handleEditContact = (contact: EmergencyContact) => {
    setEditingContact(contact);
    setFormData({ name: contact.name, phone: contact.phone });
    setFormErrors({ name: '', phone: '' });
    setIsDialogOpen(true);
  };

  const handleDeleteContact = (id: string) => {
    const success = storage.deleteEmergencyContact(id);
    
    if (success) {
      toast.success('Контакт удален');
      loadContacts();
    } else {
      toast.error('Ошибка при удалении контакта');
    }
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingContact(null);
    setFormData({ name: '', phone: '' });
    setFormErrors({ name: '', phone: '' });
  };

  const handleAddNewContact = () => {
    setEditingContact(null);
    setFormData({ name: '', phone: '' });
    setFormErrors({ name: '', phone: '' });
    setIsDialogOpen(true);
  };

  const filteredContacts = contacts.filter(contact =>
    contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.phone.includes(searchQuery)
  );

  return (
    <div className="min-h-screen" style={{ backgroundColor: colors.bg }}>
      {/* Шапка */}
      <div className="flex items-center justify-between p-4 bg-white shadow-sm">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-semibold text-lg" style={{ color: colors.text }}>
              Экстренные контакты
            </h1>
            <p className="text-sm text-gray-500">
              {contacts.length} {contacts.length === 1 ? 'контакт' : 'контактов'}
            </p>
          </div>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button
              onClick={handleAddNewContact}
              className="text-white"
              style={{ backgroundColor: colors.primary }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Добавить
            </Button>
          </DialogTrigger>
          
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>
                {editingContact ? 'Редактировать контакт' : 'Добавить контакт'}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Имя</Label>
                <Input
                  id="name"
                  placeholder="Введите имя"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className={formErrors.name ? 'border-red-300' : ''}
                />
                {formErrors.name && (
                  <p className="text-sm text-red-600">{formErrors.name}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="phone">Номер телефона</Label>
                <Input
                  id="phone"
                  placeholder="+7 (777) 123-45-67"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className={formErrors.phone ? 'border-red-300' : ''}
                />
                {formErrors.phone && (
                  <p className="text-sm text-red-600">{formErrors.phone}</p>
                )}
              </div>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={handleCloseDialog}>
                Отмена
              </Button>
              <Button 
                onClick={handleSaveContact}
                style={{ backgroundColor: colors.primary, color: 'white' }}
              >
                {editingContact ? 'Сохранить' : 'Добавить'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="p-6 max-w-2xl mx-auto space-y-6">
        {/* Поиск */}
        {contacts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Поиск по имени или номеру..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </motion.div>
        )}

        {/* Информационная карточка */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="p-4 bg-blue-50 border-blue-200">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-blue-800 font-medium mb-1">
                  Экстренные контакты
                </p>
                <p className="text-xs text-blue-700 leading-relaxed">
                  Добавьте доверенных людей, которым можно быстро отправить 
                  сообщение о помощи с вашим местоположением. Рекомендуется 
                  добавить 2-3 контакта.
                </p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Список контактов */}
        <AnimatePresence mode="popLayout">
          {filteredContacts.length > 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="space-y-3"
            >
              {filteredContacts.map((contact) => (
                <ContactItem
                  key={contact.id}
                  contact={contact}
                  onEdit={handleEditContact}
                  onDelete={handleDeleteContact}
                />
              ))}
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-center py-12"
            >
              <div 
                className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4"
                style={{ backgroundColor: colors.primaryMuted }}
              >
                <Users className="w-10 h-10" style={{ color: colors.primary }} />
              </div>
              
              <h3 className="text-lg font-semibold mb-2" style={{ color: colors.text }}>
                {searchQuery ? 'Контакты не найдены' : 'Нет экстренных контактов'}
              </h3>
              
              <p className="text-gray-500 mb-6 max-w-sm mx-auto">
                {searchQuery 
                  ? `По запросу "${searchQuery}" ничего не найдено. Попробуйте изменить поисковый запрос.`
                  : 'Добавьте доверенных людей для быстрой отправки сообщений о помощи.'
                }
              </p>
              
              {!searchQuery && (
                <Button
                  onClick={handleAddNewContact}
                  size="lg"
                  className="text-white"
                  style={{ backgroundColor: colors.primary }}
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Добавить первый контакт
                </Button>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Быстрые действия для всех контактов */}
        {contacts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold" style={{ color: colors.text }}>
                    Массовая рассылка
                  </h3>
                  <p className="text-sm text-gray-500">
                    Отправить сообщение всем контактам одновременно
                  </p>
                </div>
                
                <Button
                  variant="outline"
                  style={{ borderColor: colors.danger, color: colors.danger }}
                  onClick={() => toast.info('Функция будет добавлена в следующих версиях')}
                >
                  <AlertCircle className="w-4 h-4 mr-2" />
                  SOS всем
                </Button>
              </div>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default ContactsScreen;